import { Forecast } from './forecast';

export interface City {
  name: string;
  forecast: Forecast;
}
